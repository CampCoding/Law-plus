import Login from './Login';
import Pinding from './Pinding';
import Signup from './Signup';
import ForgetPassword from './ForgetPassword';
import EnterCodeForResetPassword from './EnterCodeForResetPassword';
import NewPassword from './NewPassword';
export {
  Login,
  Pinding,
  Signup,
  ForgetPassword,
  EnterCodeForResetPassword,
  NewPassword,
};
