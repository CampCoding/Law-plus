const noData = require('../../assets/lottie/noData.json');

export default {
  noData,
};
