const Domain = 'https://camp-coding.org/cairo_u_law_acc/student/';
const appName = 'Angol Academy';
const splashSlogan = "don't study hard, study smart";

export default {
  Domain,
  appName,
  splashSlogan,
};
