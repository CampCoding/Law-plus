import SwitchControle from './SwitchControle';
import IntroSlider from './IntroSlider';
export {SwitchControle, IntroSlider};
